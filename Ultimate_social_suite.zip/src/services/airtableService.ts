import axios from 'axios';

const AIRTABLE_API_KEY = 'patL2qM5BxtZ0FLzr.e003e2da34ef3ffe13515922cfd839a31c14f650fee117c2ddaf4ca44f88eed2';
const AIRTABLE_BASE_ID = 'appRHbWQu9VwOk33j';
const AIRTABLE_TABLE_NAME = 'uss_base';

const airtableApi = axios.create({
  baseURL: `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${AIRTABLE_TABLE_NAME}`,
  headers: {
    Authorization: `Bearer ${AIRTABLE_API_KEY}`,
  },
});

export const getUserByEmail = async (email: string) => {
  try {
    const response = await airtableApi.get('', {
      params: {
        filterByFormula: `{email} = '${email}'`,
      },
    });
    return response.data.records[0];
  } catch (error) {
    console.error('Error fetching user:', error);
    return null;
  }
};

export const authenticateUser = async (email: string, password: string) => {
  const user = await getUserByEmail(email);
  if (!user) return null;

  // Note: In a real-world scenario, you should use proper password hashing
  // For this example, we're directly comparing passwords
  if (user.fields.password !== password) return null;

  return {
    id: user.id,
    email: user.fields.email,
    givenName: user.fields.given_name,
    familyName: user.fields.family_name,
    subscriptionPlan: user.fields.subscription_plan,
    profilePictureUrl: user.fields.profile_picture_url?.[0]?.url,
    bio: user.fields.bio,
    twitterHandle: user.fields.twitter_handle,
    facebookHandle: user.fields.facebook_handle,
    instagramHandle: user.fields.instagram_handle,
    registrationDate: user.fields.registration_date,
    lastLogin: user.fields.last_login,
    posts: user.fields.Posts ? user.fields.Posts.length : 0,
    analytics: user.fields.Analytics || 0,
  };
};

export const updateLastLogin = async (userId: string) => {
  try {
    await airtableApi.patch(`/${userId}`, {
      fields: {
        last_login: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Error updating last login:', error);
  }
};

export const createUser = async (name: string, email: string, password: string) => {
  try {
    const [givenName, familyName] = name.split(' ');

    const response = await airtableApi.post('', {
      fields: {
        email,
        password, // Note: In a real-world scenario, this should be hashed
        given_name: givenName,
        family_name: familyName,
        subscription_plan: 'free',
        registration_date: new Date().toISOString(),
        last_login: new Date().toISOString(),
      },
    });

    return {
      id: response.data.id,
      email: response.data.fields.email,
      givenName: response.data.fields.given_name,
      familyName: response.data.fields.family_name,
      subscriptionPlan: response.data.fields.subscription_plan,
    };
  } catch (error) {
    console.error('Error creating user:', error);
    return null;
  }
};